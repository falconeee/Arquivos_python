import RPi.GPIO as GPIO
from flask import Flask, render_template, request
from func_aux import measure_current,measure_angle,gps
import Adafruit_MCP3008
import serial
import time
app = Flask(__name__)

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

CLK  = 21
MISO = 19
MOSI = 20
CS   = 16
mcp = Adafruit_MCP3008.MCP3008(clk=CLK, cs=CS, miso=MISO, mosi=MOSI)

#GPIOs para cada botão
B1 = 17
B2 = 27
B3 = 18
B4 = 22
B5 = 23
B6 = 24
B7 = 5
B8 = 6
# Define GPIOs como saída
GPIO.setup(B1, GPIO.OUT)   
GPIO.setup(B2, GPIO.OUT) 
GPIO.setup(B3, GPIO.OUT)
GPIO.setup(B4, GPIO.OUT)
GPIO.setup(B5, GPIO.OUT)
GPIO.setup(B6, GPIO.OUT)
GPIO.setup(B7, GPIO.OUT)
GPIO.setup(B8, GPIO.OUT) 
# Setando como LOW 
GPIO.output(B1, GPIO.LOW)
GPIO.output(B2, GPIO.LOW)
GPIO.output(B3, GPIO.LOW)
GPIO.output(B4, GPIO.LOW)
GPIO.output(B5, GPIO.LOW)
GPIO.output(B6, GPIO.LOW)
GPIO.output(B7, GPIO.LOW)
GPIO.output(B8, GPIO.LOW)
	
@app.route("/<deviceName>/<action>")
def action(deviceName, action):
	if deviceName == 'B1':
		actuator = B1
	if deviceName == 'B2':
		actuator = B2
	if deviceName == 'B3':
		actuator = B3
	if deviceName == 'B4':
		actuator = B4
	if deviceName == 'B5':
		actuator = B5
	if deviceName == 'B6':
		actuator = B6
	if deviceName == 'B7':
		actuator = B7
	if deviceName == 'B8':
		actuator = B8
		
	if action == "on":
		GPIO.output(actuator, GPIO.HIGH)
		current = measure_current(mcp)
		angle = measure_angle(mcp)
		cord = gps()
		GPIO.output(actuator, GPIO.LOW)
	
	if action == "on" and actuator == B5 or actuator == B6 or actuator == B7 or actuator == B8:
		GPIO.output(actuator, GPIO.HIGH)
	
	if action == "off":
		GPIO.output(actuator, GPIO.LOW)
		current = measure_current(mcp)
		angle = measure_angle(mcp)
		cord = gps()
	
	templateData = {
			'current': current,
			'angle': angle,
			'lat': cord[0],
			'long': cord[1]
		}
	
	return render_template('index.html', **templateData)

if __name__ == "__main__":
	app.run(host='0.0.0.0', port=80, debug=True)
   
