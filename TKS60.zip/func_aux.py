import Adafruit_MCP3008 # Conversor ADC
import serial
import time

 # MCP3008 - Software SPI configuration:
CLK  = 21
MISO = 19
MOSI = 20
CS   = 16
mcp = Adafruit_MCP3008.MCP3008(clk=CLK, cs=CS, miso=MISO, mosi=MOSI)

def measure_current(mcp):

    max_value = 0
    # pega o valor de pico em um intervalo ~0.5s. 
    for x in range(0,500):
        value = mcp.read_adc(0)
        if value > max_value:
            max_value = value
            
    max_current = ((max_value-584)/1024)*(140) #conversão
    if max_current < 0:
        max_current = 0.0
    return max_current

def measure_angle(mcp):

    value = mcp.read_adc(1)
        
    angulo = (value*270)/1023 #conversão
    
    return angulo

def gps():
    aux = 0
    gps = serial.Serial("/dev/ttyS0",115200, timeout=1)
    gps.write("AT+CGPSINFO\r".encode())
    time.sleep(0.5)
    while aux<2:
        output = gps.readline()
        aux = aux+1

    dados = str(output)


    lat_graus = dados[13:15]
    lat_min = dados[15:24]
    lat_pos = dados[25]

    long_graus = dados[28:30]
    long_min = dados[30:39]
    long_pos = dados[40]

    dia = dados[42:44]
    mes = dados[44:46]
    ano = dados[46:48]

    hora = dados[49:51]
    hora = int(hora) - 3
    hora = str(hora)
    minutos = dados[51:53]
    segundos = dados[53:55]

    latitude = lat_graus+"º"+lat_min+"'"+" "+lat_pos
    longitude = long_graus+"º"+long_min+"'"+" "+long_pos
    data = dia+"/"+mes+"/"+ano
    hora = hora+":"+minutos+":"+segundos
    return latitude,longitude
