import Adafruit_MCP3008 # Conversor ADC

 # MCP3008 - Software SPI configuration:
CLK  = 21
MISO = 19
MOSI = 20
CS   = 16
mcp = Adafruit_MCP3008.MCP3008(clk=CLK, cs=CS, miso=MISO, mosi=MOSI)

def measure_angle(mcp):

    value = mcp.read_adc(1)
        
    angulo = (value*270)/1023 #conversão
    
    return angulo

