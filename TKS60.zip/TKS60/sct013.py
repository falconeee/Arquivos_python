import Adafruit_MCP3008 # Conversor ADC

 # MCP3008 - Software SPI configuration:
CLK  = 21
MISO = 19
MOSI = 20
CS   = 16
mcp = Adafruit_MCP3008.MCP3008(clk=CLK, cs=CS, miso=MISO, mosi=MOSI)

def measure_current(mcp):

    max_value = 0
    # pega o valor de pico em um intervalo ~0.5s. 
    for x in range(0,500):
        value = mcp.read_adc(0)
        if value > max_value:
            max_value = value
            
    max_current = ((max_value-584)/1024)*(140) #conversão
    if max_current < 0:
        max_current = 0.0
    return max_current

