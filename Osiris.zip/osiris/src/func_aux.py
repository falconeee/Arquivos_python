def cria_comando(com):
    #Calcula o checksum e cria o comando
    #Cria uma lista para receber os caracteres separadamente
    carac = []
    #Percorre a lista convertendo os caracteres para hexadecimal
    for i in com:
        var_hex = i.encode().hex()
        carac.append(var_hex)

    var_hex = carac[0]
    del carac[0]

    #Faz a soma hexadecimal da lista
    for j in carac:
        var_hex = hex(int(j, 16) + int(var_hex, 16))

    #Pega os dois últimos caracteres da soma
    var_hex = var_hex[-2:]

    #Cria o comando a ser usado
    comando = "!" + com + var_hex + "\r"
    #print ("Retorno: \n" + comando)

    return comando


def comando_F (com, out):
    #Verifica a quantidade de amostras/samples registrados (a última amostra pode estar em andamento)
    com1 = out
    tam = 2
    tamComando = len(com) + 1

    comando = com1[tamComando:len(com1) - 3]
    
    res1Limpo = [comando[y - tam:y] for y in range(tam, len(comando) + tam, tam)]
    print("\n")
    print(res1Limpo)
    print("\n")
    
    qtdSample = comando[:2]
    qtdSample = int(qtdSample, 16) - 1

    return qtdSample


def comando_1_mem (com, out, mem):
    com1 = out
    tam = 4
    tamComando = len(com) + 1

    comando = com1[tamComando:len(com1) - 3]
    
    memorias = []
    memorias = [comando[y - tam:y] for y in range(tam, len(comando) + tam, tam)]
    #print("\n")
    print(mem)
    print(memorias)
    print("\n")

    return memorias[0:1]


def comando_1_leitura (com, out, leitura):
    com1 = out
    tamComando = len(com) + 1

    cabecalho = com1[tamComando:len(com1) - 3]
    
    # print("\n")
    # print(leitura)
    # print(cabecalho)
    # print("\n")

    return cabecalho


def comando_a_units(com_units_int, out_units_int, com_units_ext, out_units_ext):
    tam = 16
    
    #Units internas
    com1_int = out_units_int
    tamComando_int = len(com_units_int) + 1
    comando_int = com1_int[tamComando_int:len(com1_int) - 3]
    
    units = []
    units = [comando_int[y - tam:y] for y in range(tam, len(comando_int) + tam, tam)]
    
    #Units externas
    com1_ext = out_units_ext
    tamComando_ext = len(com_units_ext) + 1
    comando_ext = com1_ext[tamComando_ext:len(com1_ext) - 3]

    units.extend([comando_ext[y - tam:y] for y in range(tam, len(comando_ext) + tam, tam)])
    print(units)
    
    unit_tsp = (units[0])
    unit_pm10 = (units[1])
    unit_pm25 = (units[2])
    unit_pm1 = (units[3])
    unit_ext1 = (units[4])
    unit_ext2 = (units[5])
    unit_wspd = (units[6])
    unit_wdir = (units[7])
    
    #Isola as unidades do restante
    unit_tsp = unit_tsp[(unit_tsp.find(" ")+1):].replace(" ", "")
    unit_pm10 = unit_pm10[(unit_pm10.find(" ")+1):].replace(" ", "")
    unit_pm25 = unit_pm25[(unit_pm25.find(" ")+1):].replace(" ", "")
    unit_pm1 = unit_pm1[(unit_pm1.find(" ")+1):].replace(" ", "")
    unit_ext1 = unit_ext1[(unit_ext1.find(" ")+1):].replace(" ", "")
    unit_ext2 = unit_ext2[(unit_ext2.find(" ")+1):].replace(" ", "")
    unit_wspd = unit_wspd[(unit_wspd.find(" ")+1):].replace(" ", "")
    unit_wdir = unit_wdir[(unit_wdir.find(" ")+1):].replace(" ", "")
    
    return unit_tsp, unit_pm10, unit_pm25, unit_pm1, unit_ext1, unit_ext2, unit_wspd, unit_wdir
    

def comando_a_scales(com_scales, out_scales):
    tam = 8
    
    com1_scales = out_scales
    tamComando_scales = len(com_scales) + 1
    comando_scales = com1_scales[tamComando_scales:len(com1_scales) - 3]

    scales = []
    scales = [comando_scales[y - tam:y] for y in range(tam, len(comando_scales) + tam, tam)]

    print(scales)
    
    sc_tsp = float(scales[0])
    sc_pm10 = float(scales[1])
    sc_pm25 = float(scales[2])
    sc_pm1 = float(scales[3])
    sc_ext1 = float(scales[4])
    sc_ext2 = float(scales[5])
    sc_wspd = float(scales[6])
    sc_wdir = float(scales[7])
    
    
    return sc_tsp, sc_pm10, sc_pm25, sc_pm1, sc_ext1, sc_ext2, sc_wspd, sc_wdir


def comando_a_offset(com_offset, out_offset):

    tam = 8
    
    com1_offset = out_offset
    tamComando_offset = len(com_offset) + 1
    comando_offset = com1_offset[tamComando_offset:len(com1_offset) - 3]

    offset = []
    offset = [comando_offset[y - tam:y] for y in range(tam, len(comando_offset) + tam, tam)]

    print(offset)
    
    off_tsp = float(offset[0])
    off_pm10 = float(offset[1])
    off_pm25 = float(offset[2])
    off_pm1 = float(offset[3])
    off_ext1 = float(offset[4])
    off_ext2 = float(offset[5])
    off_wspd = float(offset[6])
    off_wdir = float(offset[7])
    
    
    return off_tsp, off_pm10, off_pm25, off_pm1, off_ext1, off_ext2, off_wspd, off_wdir


def comando_a_channels(com_chn_int, out_chn_int, com_chn_ext, out_chn_ext):
    tam = 16
    
    #chn internas
    com1_int = out_chn_int
    tamComando_int = len(com_chn_int) + 1
    comando_int = com1_int[tamComando_int:len(com1_int) - 3]
    
    chn = []
    chn = [comando_int[y - tam:y] for y in range(tam, len(comando_int) + tam, tam)]
    
    #chn externas
    com1_ext = out_chn_ext
    tamComando_ext = len(com_chn_ext) + 1
    comando_ext = com1_ext[tamComando_ext:len(com1_ext) - 3]

    chn.extend([comando_ext[y - tam:y] for y in range(tam, len(comando_ext) + tam, tam)])
    print(chn)
    
    chn_tsp = (chn[0])
    chn_pm10 = (chn[1])
    chn_pm25 = (chn[2])
    chn_pm1 = (chn[3])
    chn_ext1 = (chn[4])
    chn_ext2 = (chn[5])
    chn_ext3 = (chn[6])
    chn_ext4 = (chn[7])
    
    print(chn_tsp)
    print(chn_pm10)
    print(chn_pm25)
    print(chn_pm1)
    print(chn_ext1)
    print(chn_ext2)
    print(chn_ext3)
    print(chn_ext4)
    
    return chn_tsp, chn_pm10, chn_pm25, chn_pm1, chn_ext1, chn_ext2, chn_ext3, chn_ext4