from func_aux import cria_comando,comando_a_channels
import serial

from abre_yaml import config


#Define a conexão serial com o osiris
osiris = serial.Serial(
    port=config["port_serial"],
    baudrate=9600,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    timeout=1
    )

# Abre conexão com o osiris
osiris.isOpen()

modelo = config["modelo"]
serie = config["serie"]

#Descobre chn e scales dos valores
code_chn_int = "a" + "02C0"
code_chn_ext = "a" + "0300"

com_chn_int = modelo + serie + code_chn_int
com_chn_ext = modelo + serie + code_chn_ext
            
#Envia o comando para o osiris
osiris.write(cria_comando(com_chn_int).encode())
#Lê a resposta do osiris
out_chn = ""
out_chn_int = osiris.read(100).decode()

#Envia o comando para o osiris
osiris.write(cria_comando(com_chn_ext).encode())
#Lê a resposta do osiris
out_chn = ""
out_chn_ext = osiris.read(100).decode()

out_chn_int = ":O4429a02C0Total Particles PM10 particles  PM2.5 particles Rainfall        47"
out_chn_ext = ":O4429a0300Temperature     Humidity        Wind Speed      Wind Direction  34"

#Chama funções
chn_tsp, chn_pm10, chn_pm25, chn_pm1, chn_ext1, chn_ext2, chn_ext3, chn_ext4 = comando_a_channels(com_chn_int, out_chn_int, com_chn_ext, out_chn_ext)


