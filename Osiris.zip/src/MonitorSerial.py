#Comunicação Serial com o Osiris

import serial

def separa_caracteres(comando, tam_com, tam_res):
	comando_limpo = comando[tam_com:len(comando)-3]
	comando_separado = [comando_limpo[y-tam_res:y] for y in range(tam_res, len(comando_limpo) + tam_res, tam_res)]
	return comando_separado

print("\n\n\n\n\n## Comunicação Serial - Osiris ##\n")
# Modelo = input("Qual o modelo do equipamento? ")
# Serie = input("Qual a série do equipamento?  ")

Modelo = "O"
Serie = "4429"

while True:
    #Define a conexão serial com o Osiris
    Osiris = serial.Serial(
        port='/dev/ttyUSB0',
        baudrate=9600,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        timeout=1
        )

    #Abre a conexão com o Osiris
    Osiris.isOpen()
    
    #Recebe o comando pelo terminal
    code = input("\nDigite o comando desejado: ")

    com = Modelo + Serie + code

    #Calcula qtd caracteres comando e tamanho das separações
    tam_com = len(com) + 1

    if code == "F":
        tam_res = 2
    else:
        if code[:1] == "a":
            tam_res = 16
        else:
            tam_res = 4
        
    #Calcula o checksum e cria o comando
    #Cria uma lista para receber os caracteres separadamente
    carac = []
    #Percorre a lista convertendo os caracteres para hexadecimal
    for i in com:
        var_hex = i.encode().hex()
        carac.append(var_hex)

    var_hex = carac[0]
    del carac[0]

    #Faz a soma hexadecimal da lista
    for j in carac:
        var_hex = hex(int(j, 16) + int(var_hex, 16))

    #Pega os dois últimos caracteres da soma
    var_hex = var_hex[-2:]

    #Cria o comando a ser usado
    comando = "!" + com + var_hex + "\r"
    print ("\nRetorno: \n" + comando)
    
    #Envia o comando para o Osiris
    Osiris.write(comando.encode())

    #Lê a resposta do Osiris
    out = ""
    out = Osiris.read(100).decode()

    #Imprime a resposta
    print(out + "\r")

    print(separa_caracteres(out, tam_com, tam_res))