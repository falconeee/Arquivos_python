import yaml
import os.path

arquivo = "config.yaml"

with open(("./config/"+arquivo), 'r') as config:
  config = yaml.safe_load(config)
  