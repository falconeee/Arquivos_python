def sensor_rainfall(delta,count_rain,rain_bucket,):
    """rain_volume_per_sec"""
    
    return (count_rain * rain_bucket) / delta
    