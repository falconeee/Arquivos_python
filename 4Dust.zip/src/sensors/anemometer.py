from numpy import interp

# Anemometer - Function to calculate the results from the sensor
def sensor_anemometer(mcp,delta,ADC_CHANNEL_WINDDIR,V_REF,wind_count,dir_offset):
    
    north = 5000
    west = 3750
    south = 2500
    east = 1250
    
    # Anemometer - Wind Dirtection
    # Adjusting the right interp to return the angle
    valueWindDir = (mcp.read_adc(ADC_CHANNEL_WINDDIR)/1024)*V_REF # mili Volts
    
    if (valueWindDir <= north and valueWindDir >= west+1):
        wind_angle = interp(valueWindDir, [west+1, north], [89, 0])
        wind_angle = round(wind_angle, 1)
    elif (valueWindDir <= west and valueWindDir >= south+1):
        wind_angle = interp(valueWindDir, [south+1, west], [179, 90])
        wind_angle = round(wind_angle, 1)
    elif (valueWindDir <= south and valueWindDir >= east+1):
        wind_angle = interp(valueWindDir, [east+1, south], [269, 180])
        wind_angle = round(wind_angle, 1)
    elif (valueWindDir <= east and valueWindDir >= 22):
        wind_angle = interp(valueWindDir, [22, east], [350, 270])
        wind_angle = round(wind_angle, 1)
    else:
        wind_angle = 355

    direction = wind_angle - dir_offset
    if (direction > 360):
        wind_angle = direction - 360
    elif (direction < 0):
        wind_angle = direction + 360
    else:
        wind_angle = direction

    # Anemometer - Wind Speed
    wind_speed_ms = float(wind_count * (2.25 / delta) * 0.44704)
    
    return wind_speed_ms,valueWindDir,wind_angle
