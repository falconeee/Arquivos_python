def sensor_temperature_relative(ADC_CHANNEL_TEMP,ADC_CHANNEL_HUMI,V_REF,mcp):
    
    valueTemp = mcp.read_adc(ADC_CHANNEL_TEMP)
    valueHumi = mcp.read_adc(ADC_CHANNEL_HUMI)
    temp = (((valueTemp/1024)*(V_REF/10))) - 40 # mili Volts
    humi = (valueHumi/1024)*(V_REF/10)

    return temp,humi