#========================================================
# opc_http.py
# rotinas para requests http
# Alphalink 20/02/2021
#========================================================

import requests
import queue
import threading
import time
import src.controllers.files as opc_files
import json

#==================================================
# Classe OPC_HTTP

class OPC_HTTP:
    
    def __init__(self, **kwargs):
        self.Debug = kwargs.get('debug',False)
        self.qhttp = queue.Queue()

        opc_files.ReadQueue('config/opc_queue.bin',self.qhttp)

        thttp = threading.Thread(target=self.DoHTTP)
        thttp.start()

#-------------------------------------------------
# Envia request HTTP

    def SendHTTP(self,url,hist):
        try:
            pacote = json.dumps([{i[0]: i[1]} for i in hist])
##            if self.Debug:
##                print('HTTP ',url,pacote)
            r = requests.post(url,json = pacote, timeout=3)

            if r.status_code in [200,201,202]:
                return True
            
            if self.Debug:
                print('Erro HTTP %d'%(r.status_code))
        except:
            if self.Debug:
                print('Erro HTTP')

        return False
        
#-------------------------------------------------
# Thread

    def DoHTTP(self):
        if self.Debug:
            print('DoHTTP Iniciado')
        self.HTTPEnd = False

        save = False
        clean = self.qhttp.qsize()>0
        size = 0
        
        while not self.HTTPEnd:
            try:
                if not self.qhttp.empty():
                    surl,post = self.qhttp.queue[0]
                    if self.SendHTTP(surl,post):
                        self.qhttp.get()
                        if clean:
                            save = True
                            clean = self.qhttp.qsize()>0
 
                    else:
                        clean = True
                        qs = self.qhttp.qsize()
                        if size != qs:
                            size = qs
                            save = True
                        time.sleep(3)

                    if save:
                        save = False
                        opc_files.WriteQueue('config/opc_queue.bin',self.qhttp)
                        if self.Debug:
                            print('Salvo opc_queue.bin')
                    
            except:
                if self.Debug:
                    print('Erro Process HTTP')

            time.sleep(0.1)
                    
        opc_files.WriteQueue('config/opc_queue.bin',self.qhttp)
        if self.Debug:
            print('DoHTTP Finalizado')

#-------------------------------------------------
# Finaliza thread

    def StopHTTP(self):
        self.HTTPEnd = True

#-------------------------------------------------
# Envia  para a fila o conteudo a ser enviado

    def QueueHTTP(self,url,post):
        self.qhttp.put((url,post))

#==================================================

#ht = OPC_HTTP(debug=True)
#ht.QueueHTTP('http://127.0.0.1:1880/dust',{'user':1,'pass':2})
