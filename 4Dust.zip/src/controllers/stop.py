import src.controllers.spi as spi


# # cria uma instancia da classe
# opc1 = spi.OPC_SPI(debug=True)

# opc1.Open(0,0)
# opc1.LaserOff()
# opc1.FanOff()
# opc1.Close()

def off_safe():
# cria uma instancia da classe
    opc1 = spi.OPC_SPI(debug=True)

    opc1.Open(0,0)
    opc1.LaserOff()
    opc1.FanOff()
    opc1.Close()
