import time
from datetime import datetime

import src.controllers.files as opc_files
import src.controllers.spi as opc_spi
import src.controllers.http as opc_http

def process(**kwargs):
        global pm_data
        debug = kwargs.get('debug',True)
        
        fcfg = kwargs.get('config','opc_spi.conf')
        cfg = opc_files.ReadConfig(fcfg)
        if len(cfg)==0:
            cfg = [('bus', '0'),
                   ('device', '0'),
                   ('quantidade', '1'),
                   ('intervalo', '5'),
                   ('pasta', 'src/config/'),
                   ('arquivo', 'opc_d'),
                   ('limpeza', '14'),
                   ('url', 'http://127.0.0.1:1880/dust'),
                   ('envia', 'sim')]
        
        bus = int(kwargs.get('bus',cfg[0][1]))
        device = int(kwargs.get('device',cfg[1][1]))
        nitr = int(kwargs.get('nitr',cfg[2][1]))
        interv = int(kwargs.get('interv',cfg[3][1]))
        sdir = kwargs.get('path',cfg[4][1])
        sarq = kwargs.get('arq',cfg[5][1])
        limp = int(kwargs.get('arq',cfg[6][1]))
        surl = kwargs.get('url',cfg[7][1]) 
        http = kwargs.get('envia',cfg[8][1]) == 'sim'

        http1 = opc_http.OPC_HTTP(debug=debug)
        time.sleep(0.1)

        # abre comunicação com SPI com device 0 e CE0
        opc1 = opc_spi.OPC_SPI(debug = debug)

        res = opc_files.ReadSeq(sdir,sarq)
        if res==[]:
            opc1.nseq = 1
        else:
            opc1.nseq = int(res[0])+1

        opc1.Open(bus,device)

        # le número de série
        if debug:
            nserie = opc1.GetStr(0x10,60)
            print(nserie)

        # le versão do firmware
        if debug:
            strfirm = opc1.GetStr(0x3f,60)
            print(strfirm)

        # liga ventilador e Laser
        opc1.FanOn()
        time.sleep(1)
        opc1.LaserOn()
        time.sleep(1)
        #hist = opc1.GetHistogram()  # Limpa histograma
        #+++++++++++++++++++++++++++++++++++++++
        utemp = datetime.timestamp(datetime.now())
        k = 0
        pm_data_aux = ['0', '0', '0']
        while (k < nitr) or (nitr<=0):
            try:
                now = datetime.timestamp(datetime.now())
                if abs(now-utemp) > (interv):
                    utemp = now
                    hist = opc1.GetHistogram()
                        
                    opc1.nseq += 1

                    if opc_files.SaveCSV(sdir+sarq+datetime.now().strftime('%Y%m%d%H')+'.csv',hist):
                        opc_files.CleanFile(sdir,sarq,limp)

                    if http:
                        http1.QueueHTTP(surl,hist)
                    
                    if debug:
                        print('Sequencia %d'%(opc1.nseq-1))

                    if nitr>0:
                        k+=1

                    pm_data = opc1.pm_send()
                    if (pm_data[2] > pm_data_aux[2]):
                            pm_data_aux = pm_data

                    time.sleep(interv)
            except:
                if debug:
                    print('Erro Process OPC')
        #+++++++++++++++++++++++++++++++++++++++

        pm_data = pm_data_aux
        
        http1.StopHTTP()
                
        # desliga laser e ventilador
        opc1.LaserOff()
        time.sleep(1)
        opc1.FanOff()
        
        # fecha comunicação com SPI
        opc1.Close()

        #


#==================================================
def fpm_data():
        global pm_data
        return pm_data

#Process(debug=True, config='opc_dust.conf', nitr=2, interv=5)
        


