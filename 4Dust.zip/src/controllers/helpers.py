import time
import RPi.GPIO as GPIO
from src.sensors import Display
import os
import sys
from datetime import datetime 
import Adafruit_SSD1306
from src.controllers.stop import off_safe
import serial

def signal_handler(sig, frame):
    """ Function to stop the program with CTRL+C
    input: Display - objeto display
    """
    display = Adafruit_SSD1306.SSD1306_128_32(rst=None) # 128x32 display with hardware I2C
    GPIO.cleanup()
    off_safe()
    time.sleep(1)
    display.clear()
    display.display()
    sys.exit(0)

def str_results(temp,humi,wind_speed_ms,wind_angle,rain_bucket,rain_volume_per_sec,dir_offset,pm_data,quality):

    json_results = {
        "time" : datetime.now().strftime(' %H:%Mh   %d/%m/%Y'),
        "Temperature": "{:.1f} °C".format(temp),
        "Humidity": "{:.1f} %".format(humi),
        "Wind speed": "{:.2f} m/s".format(wind_speed_ms, (wind_speed_ms*3.6)),
        "Wind direction": "{:.0f}°".format(wind_angle),
        "Bucket size": "{:.3f} mm/s".format(rain_bucket),
        "Rain fall": "{:.3f} mm/s".format(rain_volume_per_sec),
        "Offset angle": "{}°".format(dir_offset),
        "pm_data":pm_data,
        "quality":quality
    }

    return json_results

def shutdown_break_energy(display:Display):
    off_safe()
    time.sleep(1)
    display.shutdown()
    time.sleep(2)
    display.clear()
    display.display()
    os.system("sudo shutdown -h now")
                
def select_reboot_shutdown(reboot_shutdown_button:int,display:Display)->None:
    """ Função para desligar e reiniciar o sistema
    input: reboot_shutdown_button - botão
    input: Display - objeto display
    return: None
    """
    i = 0
    time.sleep(0.5)
    
    if (GPIO.input(reboot_shutdown_button) == GPIO.HIGH):
        while (i < 10):
            if (GPIO.input(reboot_shutdown_button) == GPIO.HIGH):
                display.select_reboot()

            elif (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
                off_safe()
                display.rebooting()
                time.sleep(2)
                display.clear()
                display.display()
                os.system("sudo reboot -h now")
                
            i = i + 1
            time.sleep(0.2)
                            
        while (i < 20):
            if (GPIO.input(reboot_shutdown_button) == GPIO.HIGH):
                display.select_shutdown()

            elif (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
                off_safe()
                display.shutdown()
                time.sleep(2)
                display.clear()
                display.display()
                os.system("sudo shutdown -h now")

            i = i + 1   
            time.sleep(0.2)
            
        display.page_inicial()
        display.display()  

def signal_quality():

    sim7600 = serial.Serial("/dev/ttyS0", baudrate=115200, timeout=1)

    # Sinal 
    code = "AT+CSQ" + "\r\n"
    sim7600.write(code.encode())
    signal = sim7600.read(100).decode()
    aux1 = signal.find("OK")

    # Internet
    code = "AT+CGREG?" + "\r\n"
    sim7600.write(code.encode())
    network = sim7600.read(100).decode()
    aux2 = network.find("OK")

    sim7600.close()

    if aux1>=0 and aux2>=0:
        ini = signal.find("+CSQ: ")
        value_signal = signal[ini+6:ini+10]
        value_signal = value_signal.replace(",",".")
        value_signal = float(value_signal)

        ini = network.find("+CGREG: ")
        value_network = network[ini+8:ini+11]
        value_network = value_network.replace(",",".")
        value_network = float(value_network)

        if value_network!=0.1 and value_network!=0.5:
            return value_signal,"NO NETWORK"
        elif value_signal <= 9:
            return value_signal,"MARGINAL"
        elif value_signal > 9 and value_signal <= 14:
            return value_signal,"OK"
        elif value_signal > 14 and value_signal <= 19:
            return value_signal,"GOOD"
        elif value_signal > 19:
            return value_signal,"EXCELLENT"

    else:
        return "NO SIGNAL"



        
