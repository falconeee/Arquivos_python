#========================================================
# opc_spi.py
# rotinas para acesso ao OPC-N3 via SPI
# Alphalink 20/02/2021
#========================================================

import spidev
import time
from datetime import datetime
import struct

#==================================================
# Classe OPC_SPI

class OPC_SPI:
    def __init__(self, **kwargs):
        self.spi = spidev.SpiDev()
        self.Debug = kwargs.get('debug',False)
        self.nseq = 0

#-------------------------------------------------
# Abre a porta SPI
# bus 0:
#   pino 19 MOSI
#   pino 21 MISO
#   pino 23 SCLK
# device:
#   0   pino 24 CE0
#   1   pino 26 CE1

    def Open(self,bus,device):
        try:
            self.spi.open(bus,device)
            self.spi.max_speed_hz=500000
            self.spi.mode = 0b01
            self.spi.bits_per_word = 8
            return True

        except:
            return False

#-------------------------------------------------
# Aguarda um OPC_RDY

    def GetReady(self,cmd):
        try:
            for k in range(20):
                b=[cmd]
                self.spi.xfer2(b)

                if b[0]==0xf3:  #OPC_RDY, OK
                    return True

                if b[0]!=0x31:  #OPC_BUSY, Erro aguarda 2 segundos
                    if self.Debug:
                        print('Erro SPI: ',b)
                    time.sleep(2)

                time.sleep(0.001)

            return False

        except:   
            return False
    
#-------------------------------------------------
# Recebe lista de valores
# cmd   comando
# num   número de bytes

    def GetVal(self,cmd,num):
        try:
            if not self.GetReady(cmd):
                print ('OPC Not Ready')
                return []
        
            time.sleep(0.01)

            res = []
            for k in range(num):
                b = self.spi.readbytes(1)
                res.append(b[0])

            return res

        except:
            return []

#-------------------------------------------------
# Envia valor
# cmd   comando
# val   lista com valores

    def SetVal(self,cmd,val):
        try:
            if not self.GetReady(cmd):
                print ('OPC Not Ready')
                return False
        
            time.sleep(0.01)
            for v in val:
                b = [v]
                rs = self.spi.writebytes(b)
            return True
        
        except:
            return False

#-------------------------------------------------
# Recebe String
# cmd   comando
# num   número de bytes

    def GetStr(self,cmd,num):
        res = self.GetVal(cmd,num)

        rstr = ''
        for r in res:
            rstr += chr(r)

        return rstr

#-------------------------------------------------
# Encerra comunicação com porta SPI

    def Close(self):
        try:
            self.spi.close()
        except:
            pass

#-------------------------------------------------
# Comandos Liga e Desliga Ventilador

    def FanOff(self):
        self.SetVal(0x03,[0x02])
        if self.Debug:
            print('Fan Off')

    def FanOn(self):
        self.SetVal(0x03,[0x03])
        if self.Debug:
            print('Fan On')
            
#-------------------------------------------------
# Comandos Liga e Desliga Laser

    def LaserOff(self):
        self.SetVal(0x03,[0x06])
        if self.Debug:
            print('Laser Off')
            
    def LaserOn(self):
        self.SetVal(0x03,[0x07])
        if self.Debug:
            print('Laser On')

#-------------------------------------------------
# Calculo do CRC do frame recebido

    def _CalcCRC(self,res):
        crc_rx = res[-2]+res[-1]*256

        crc = 0xffff    #valor inicial
        for i in range(len(res)-2):
            crc ^= int(res[i])
            for j in range(8):
                if (crc & 1):
                    crc >>= 1
                    crc ^= 0xA001  #gerador polinomial
                else:
                    crc >>= 1

        return crc == crc_rx 

#-------------------------------------------------
# Binário para Float

    def _btof(self,res):
        b=bytearray()
        for i in range(4):
            b.append(res[i])
        [f] = struct.unpack('f',b)
        return '%5.3f'%(f)
    
#-------------------------------------------------

    def _Temperatura(self,res):
        ts = res[1] * 256 + res[0]
        tc = -45 + 175 * ts/65535
        return '%3.2f'%(tc)

    def _Umidade(self,res):
        us = res[1] * 256 + res[0]
        uc = 100 * us/65535
        return '%3.2f'%(uc)

#-------------------------------------------------
# Recebe histograma completo

    def GetHistogram(self):
        global pm_a, pm_b, pm_c
        
        try:
            res = self.GetVal(0x30,86)
            if not self._CalcCRC(res):
                if self.Debug:
                    print('CRC erro')
                return []

            hist = [('Sequencial',self.nseq)]
            hist.append(('Data/Hora',datetime.now().strftime("%Y%m%d%H%M%S%f")[0:-3]))
            hist.append(('RPi Temp',self.RPi_Temp()))

            # Bin0 a Bin23
            for i in range(24):
                hist.append(('Bin%d'%(i),res[i*2]+res[i*2+1]*256))

            # Bin1 MToF a Bin7 MTof
            for i in range(4):
                hist.append(('MToFBin%d(us)'%(i*2+1),res[48+i]))

            # Sampling Period
            hist.append(('SampPrd(s)',res[52]+res[53]*256))

            # Sample Flow Rate
            hist.append(('SFR(ml/s)',res[54]+res[55]*256))

            # Temperatura
            hist.append(('Temperatura',self._Temperatura(res[56:58])))

            # Umidade
            hist.append(('Umidade',self._Umidade(res[58:60])))

            # PM_A
            hist.append(('PM_A(ug/m^3)',self._btof(res[60:64])))
            pm_a = self._btof(res[60:64])

            # PM_B
            hist.append(('PM_B(ug/m^3)',self._btof(res[64:68])))
            pm_b = self._btof(res[64:68])

            # PM_C
            hist.append(('PM_C(ug/m^3)',self._btof(res[68:72])))
            pm_c = self._btof(res[68:72])

            # Reject count Glitch
            hist.append(('#RejectGlitch',res[72]+res[73]*256))

            # Reject count LongTOF
            hist.append(('#RejectLongTOF',res[74]+res[75]*256))

            # Reject count Ratio
            hist.append(('#RejectRatio',res[76]+res[77]*256))

            # Reject count OutOfRange
            hist.append(('#RejectCountOutOfRange',res[78]+res[79]*256))

            # Fan rev count
            hist.append(('FanRevCount',res[80]+res[81]*256))

            # Laser status
            hist.append(('LaserStatus',res[82]+res[83]*256))

            #print(hist)
            return hist   
            
        except:
            return []

#-------------------------------------------------
# Recebe histograma simples

    def GetPMData(self):
        try:
            res = self.GetVal(0x32,14)
            if not self._CalcCRC(res):
                if self.Debug:
                    print('CRC erro')
                return []

            pmdata = [('Sequencial',self.nseq)]

            # PM_A
            pmdata.append(('PM_A(ug/m^3)',self._btof(res[0:4])))

            # PM_B
            pmdata.append(('PM_B(ug/m^3)',self._btof(res[4:8])))

            # PM_C
            pmdata.append(('PM_C(ug/m^3)',self._btof(res[8:12])))

            #print(pmdata)
            return pmdata
        
        except:
            return []
        
#-------------------------------------------------
# 
    def pm_send(self):
        global pm_a, pm_b, pm_c
        
        pm_data = [pm_a]
        pm_data.append(pm_b)
        pm_data.append(pm_c)
        
        return pm_data
#-------------------------------------------------
# Le temperatura do Raspberry Pi

    def RPi_Temp(self):
        try:
            f=open("/sys/class/thermal/thermal_zone0/temp", "r")
            c = f.read()
            v = float(c) / 1000.0
            return '%3.1f'%(v)
        finally:
            f.close()

#==================================================

# cria uma instancia da classe
#opc1 = OPC_SPI(debug=True)
