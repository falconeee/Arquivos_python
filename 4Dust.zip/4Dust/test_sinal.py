import serial
import usb

def signal_quality():

    sim7600 = serial.Serial("/dev/ttyS0", baudrate=115200, timeout=1)

    # Sinal 
    code = "AT+CSQ" + "\r\n"
    sim7600.write(code.encode())
    signal = sim7600.read(100).decode()
    aux1 = signal.find("OK")

    # Internet
    code = "AT+CGREG?" + "\r\n"
    sim7600.write(code.encode())
    network = sim7600.read(100).decode()
    aux2 = network.find("OK")

    sim7600.close()

    if aux1>=0 and aux2>=0:
        ini = signal.find("+CSQ: ")
        value_signal = signal[ini+6:ini+10]
        value_signal = value_signal.replace(",",".")
        value_signal = float(value_signal)

        ini = network.find("+CGREG: ")
        value_network = network[ini+8:ini+11]
        value_network = value_network.replace(",",".")
        value_network = float(value_network)

        if value_network!=0.1 and value_network!=0.5:
            return value_signal,"NO NETWORK"
        elif value_signal <= 9:
            return value_signal,"MARGINAL"
        elif value_signal > 9 and value_signal <= 14:
            return value_signal,"OK"
        elif value_signal > 14 and value_signal <= 19:
            return value_signal,"GOOD"
        elif value_signal > 19:
            return value_signal,"EXCELLENT"

    else:
        return "NO SIGNAL"

def conect_usb():
    dev = usb.core.find()
    print(dev)

#print(signal_quality())

conect_usb()


