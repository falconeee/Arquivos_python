# opc_n3
Coletor de dados do equipamento OPC-N3, para Raspberry Pi

# Descrição do Aplicativo
  O aplicativo comunica com o equipamento OPC-N3 através da porta SPI do Raspberry Pi.
  Coleta as amostras a um configurável intervalo de tempo e grava uma linha em arquivo padrão csv, com um número sequencial de amostras.
  Envia essa linha para um aplicativo externo através de requisição http, por método POST, em padrão json.
  As requisições http são efetuadas a partir de uma fila interna ao aplicativo rodando em thread separada, para não bloquear o amostrador.
  No caso de falha de comunicação nas requisições, o aplicativo mantém as diversas requisições na fila que são reenviadas após o retorno das comunicações
  Em caso de queda de energia nesse momento, o aplicativo retoma a fila de requisições que fica gravada em arquivo.

# Cabo

	RPi 		OPC
pino 02	5V	cabo 1	V In
ou
pino 04 5V

pino 19 MOSI	cabo 4	SDI
pino 21 MISO	cabo 3	SDO
pino 23 SCLK	cabo 2	SCK
pino 25	Ground	cabo 6	GND

pino 24 CE0	cabo 5 /SS
ou
pino 26 CE1

# Uso
import opc_proc

opc_proc.Process(debug=False, config='opc_dust.conf')

debug: 
  Chave True/False para envio de informações do processo na console

config:
  Nome do arquivo de configuração descrito a seguir
  
# Arquivo de configuração

opc_dust.conf:
----------------------------------------------------
[OPC_SPI]        
bus = 0
device = 0

[Amostra]
quantidade = -1
intervalo = 15

[Arquivo]
pasta = ./csv/
arquivo = opc_d
limpeza = 14

[HTTP]
url = http://127.0.0.1:1880/dust
envia = sim
---------------------------------------------------

# [OPC_SPI]:
  Configuração da porta SPI para acesso ao equipamento
   
bus: 
  0   pino 19 MOSI
       pino 21 MISO
       pino 23 SCLK
device:
  0   pino 24 CE0
  1   pino 26 CE1
   
# [Amostra]
  Configuração das amostras a serem coletadas
  
quantidade:
  Número de amostras a serem capturadas, use -1 para amostrar sempre

intervalo:
  Tempo em segundos entre amostras

# [Arquivo]:
  Configuração do armazenamento das amostras coletadas em padrão csv (ponto e virgula)
  Os arquivos contém a primeira linha com o cabeçalho e as demais com as amostras
  Cada arquivo armazena uma hora, no nome do arquivo consta o ano, mes, dia e hora
  
pasta:
  Pasta onde os arquivos .csv são armazenados
   
arquivo:
  Inicial dos nomes dos arquivos .csv de armazenamento. 
  O sistema completa com informações de data e hora: AAAAMMDDHH

limpeza:
  Tempo em dias para auto limpeza dos arquivos .csv

# [HTTP]:
  Configuração para envio das amostras por requests http

url:
  Endereço url completo para o servidor http

envia:
  Flag sim/nao para envio dos requests http

# Instalação

  Copiar os programas python para a pasta desejada, por exemplo /home/pi/opc_dust
  Criar a pasta para conter os arquivos de armazenamento .csv, /home/pi/opc_dust/csv
  Alterar o arquivo de scrpts para as pastas configuradas:
  
Arquivo opc_dust.sh:
------------------------------------------------
cd /home/pi/opc_dust
sudo hwclock -s
while true; do
	python3 opc_dust.py
	python3 opc_stop.py
done
------------------------------------------------

  Alterar o arquivo autostart:
sudo nano /etc/xdg/lxsession/LXDE-pi/autostart

  Antes da linha xscreensaver digitar:
sh /home/pi/opc_dust/opc_dust.sh

