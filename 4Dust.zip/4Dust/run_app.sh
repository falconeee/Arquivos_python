#!/bin/sh
sudo cd /home/pi/weather-station/
sudo python3 run.py