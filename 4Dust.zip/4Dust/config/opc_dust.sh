cd /home/pi/opc_dust
sudo hwclock -s
while true; do
	python3 weather_station_with_display_rev00.py
done
