#========================================================
# opc_files.py
# rotinas para acesso a disco
# Alphalink 20/02/2021
#========================================================

import pickle
import queue
import os
import csv
import configparser
from datetime import datetime,timedelta

#========================================================
# Le arquivo binário

def ReadBin(arq):
        try:
            f = open(arq,"rb")
            load = pickle.load(f)
            f.close()
            return load
        except:
            print("\nErro ao abrir "+arq)
            return []
        
#--------------------------------------------------------
# Escreve em arquivo binário

def WriteBin(arq,load):
        try:
            f = open(arq,"wb")
            pickle.dump(load,f)
            f.close()
            return True
        except:
            print("\nErro ao salvar "+arq)
            return False

#========================================================
# Le arquivo binário e retorna em uma fila

def ReadQueue(arq, qlist):
        try:
            load = ReadBin(arq)

            for l in load:
                qlist.put(l)
            return True
        
        except:
            return False
        
#--------------------------------------------------------
# Escreve uma fila em arquivo binário

def WriteQueue(arq,qlist):
        try:
            load = []
            for q in qlist.queue:
                load.append(q)

            return WriteBin(arq,load)
        except:
            return False
    
#========================================================
# Limpa arquvos de uma pasta anteriores a dias

def CleanFile(sdir,sarq,dias):
        try:
            fold = (datetime.now()-timedelta(days=dias)).strftime('%Y%m%d%H')
        
            flist = sorted(os.listdir(sdir))
            for a in flist:
                if a[0:len(sarq)] == sarq:
                    if a[len(sarq):len(sarq)+10] < fold:
                        os.remove(sdir+a)
                        #print('Remove ',a)
        except:
            pass

#========================================================
# Grava arquivo csv com uma lista

def SaveCSV(sarq,load):
        mode = 'a'

        try:
            if not os.path.exists(sarq):
                mode = 'w'
                h=[]
                for c in load:
                    h.append(c[0])
            
            r=[]
            for c in load:
                r.append(c[1])

            with open(sarq, mode=mode) as fload:
                wload = csv.writer(fload, delimiter=';', quotechar='"')
                if mode=='w':
                    wload.writerow(h)
                wload.writerow(r)                    

        except:
            pass

        return mode=='w'

#========================================================
# Busca último número sequencial

def ReadSeq(sdir,sarq):
        try:
            flist = sorted(os.listdir(sdir),reverse=True)
            fname = ''
            for a in flist:
                if a[0:len(sarq)] == sarq:
                    fname = a
                    break

            if fname=='':
                return []

            with open(sdir+fname, mode='r') as fcsv:
                rcsv = csv.reader(fcsv, delimiter=';')
                for r in rcsv:
                    pass

            return r

        except:
            return []
                
#========================================================
# Le arquivo de configuração

def ReadConfig(fcfg):
        try:
            cfg = configparser.ConfigParser()
            cfg.read(fcfg)

            lcfg = []
            lcfg.append(('bus',cfg.get('OPC_SPI','bus')))
            lcfg.append(('device',cfg.get('OPC_SPI','device')))

            lcfg.append(('quantidade',cfg.get('Amostra','quantidade')))
            lcfg.append(('intervalo',cfg.get('Amostra','intervalo')))
            
            lcfg.append(('pasta',cfg.get('Arquivo','pasta')))
            lcfg.append(('arquivo',cfg.get('Arquivo','arquivo')))
            lcfg.append(('limpeza',cfg.get('Arquivo','limpeza')))

            lcfg.append(('url',cfg.get('HTTP','url')))
            lcfg.append(('envia',cfg.get('HTTP','envia')))

            return lcfg
        
        except:
            pass

        return []
                
#========================================================
