import main

main.process(debug=True, config='opc_dust.conf')

# Editar arquivo autostart
#sudo nano /etc/xdg/lxsession/LXDE-pi/autostart
# Antes da linha xscreensaver digitar:
#sh /home/pi/opc_n3/opc_dust.sh

#sqlite3 opc_n3.db
#CREATE TABLE reg_opc(id integer primary key autoincrement, data text, temp_rpi real, temp_opc real, umid_opc real, pma real, pmb real, pmc real, laser int, nseq int);
