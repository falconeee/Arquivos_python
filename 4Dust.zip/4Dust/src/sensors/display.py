import Adafruit_SSD1306
import datetime
import time
import RPi.GPIO as GPIO

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont


class Display():

    def __init__(self) -> None:
        self.disp = Adafruit_SSD1306.SSD1306_128_32(rst=None) # 128x32 display with hardware I2C
        self.begin()
        self.clear()
        self.display()

        # Create blank image for drawing.
        # Make sure to create image with mode '1' for 1-bit color.
        self.image = Image.new('1',(self.disp.width, self.disp.height))

        self.draw = ImageDraw.Draw(self.image)# Draw a black filled box to clear the image.
        self.rectangle()

        # Draw some shapes.
        # First define some constants to allow easy resizing of shapes.
        self.padding = -2
        self.top =  self.padding
        self.bottom =  self.disp.height- self.padding

        # Move left to right keeping track of the current self.move position for drawing shapes.
        self.move = 0
        # Load fonts.
        self.font = ImageFont.load_default()
        self.font2 = ImageFont.truetype('./config/ARIALBD.TTF', 16)

        self.count_page = 0

    def begin(self) -> None:
        return self.disp.begin()
    
    def clear(self) -> None:
        return self.disp.clear()
    
    def display(self) -> None:
        return self.disp.display()

    def rectangle(self) -> None:
        return  self.draw.rectangle((0,0,self.disp.width, self.disp.height), outline=0, fill=0)

    def image_generate(self) -> None:
        return self.disp.image(self.image)

    def page_inicial(self)->None:
        # Getting date and time
        
        now = datetime.datetime.now()
        time = now.strftime(' %H:%Mh   %d/%m/%Y')

        self.rectangle()  
        self.draw.text((self.move,self.top),time,font=self.font, fill=255)
        self.draw.text((self.move,self.top+7),str('-'*50),font=self.font,fill=255)
        self.draw.text((self.move,self.top+15),str('         4DUST'),font=self.font2, fill=255)

        # Display image.
        self.image_generate()
        self.display()

    def page_load(self) ->None:

        self.rectangle()  
        self.draw.text((self.move,self.top),str('      WELCOME'),  font=self.font2, fill=255)
        self.draw.text((self.move,self.top+22),str('         by futurai'),  font=self.font, fill=255)

        # Display image.
        self.image_generate()
        self.display()

        time.sleep(2)

        self.clear()
        self.display()

    def update_display(self,hmp60_page,anemometer_page,
                        rain_page,wind_offset_page,
                        opc_page,singal_power,reboot_shutdown_button,
                        json_results):
        
        time.sleep(0.01)
        
        # Setting page dislpay
        # HMP60 - 1
        if (hmp60_page) and (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
            # Draw a black filled box to clear the image.
            self.rectangle()
            self.draw.text((self.move, self.top), json_results["time"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+7), str('-'*50),  font=self.font, fill=255)
            self.draw.text((self.move, self.top+12),"Temperature: "+json_results["Temperature"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+23), "Humidity: "+json_results["Humidity"],  font=self.font, fill=255)
        # Anemometer - 2
        elif (anemometer_page) and (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
            # Draw a black filled box to clear the image.
            self.rectangle()
            self.draw.text((self.move, self.top), json_results["time"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+7), str('-'*50),  font=self.font, fill=255)
            self.draw.text((self.move, self.top+12),"Wind speed: "+json_results["Wind speed"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+23), "Wind direction: "+json_results["Wind direction"],  font=self.font, fill=255)
        # Rain Fall - 3
        elif (rain_page) and (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
            # Draw a black filled box to clear the image.
            self.rectangle()
            self.draw.text((self.move, self.top), json_results["time"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+7), str('-'*50),  font=self.font, fill=255)
            self.draw.text((self.move, self.top+12),"Bucket size: " +json_results["Bucket size"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+23), "Rain fall: "+json_results["Rain fall"],  font=self.font, fill=255)
        # Wind Direction Offset - 4
        elif (wind_offset_page) and (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
            # Draw a black filled box to clear the image.
            self.rectangle()
            self.draw.text((self.move, self.top), json_results["time"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+7), str('-'*50),  font=self.font, fill=255)
            self.draw.text((self.move, self.top+12), "Offset angle: "+json_results["Offset angle"],  font=self.font, fill=255)
        # OPC-N3 - 5
        elif (opc_page) and (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
            pm_data_aux = json_results["pm_data"]
            # Draw a black filled box to clear the image.
            self.rectangle()
            self.draw.text((self.move, self.top), json_results["time"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+7), str('-'*50),  font=self.font, fill=255)
            self.draw.text((self.move, self.top+12), 'PM1 | PM2.5 | PM10',  font=self.font, fill=255)
            self.draw.text((self.move, self.top+23), pm_data_aux[0]+'|'+pm_data_aux[1]+'|'+pm_data_aux[2],  font=self.font, fill=255)
        
        # signal_quality and power - 6
        elif (singal_power) and (GPIO.input(reboot_shutdown_button) == GPIO.LOW):
            # Draw a black filled box to clear the image.
            self.rectangle()
            self.draw.text((self.move, self.top), json_results["time"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+7), str('-'*50),  font=self.font, fill=255)
            self.draw.text((self.move, self.top+12),"Signal: " +json_results["quality"],  font=self.font, fill=255)
            self.draw.text((self.move, self.top+23), "Power Battery: "+"100%",  font=self.font, fill=255)
        
        self.image_generate()
        self.display()        

    def select_reboot(self):
        self.rectangle()
        self.draw.text((self.move, self.top+8), str('      REBOOT?'),  font=self.font2, fill=255)
        self.image_generate()
        self.display()

    def rebooting(self):
        self.rectangle()
        self.draw.text((self.move, self.top+8), str('    REBOOTING'),  font=self.font2, fill=255)
        self.image_generate()
        self.display()

    def select_shutdown(self):
        self.rectangle()
        self.draw.text((self.move, self.top+8), str('   SHUTDOWN?'),  font=self.font2, fill=255)
        self.image_generate()
        self.display()

    def shutdown(self):
        self.rectangle()
        self.draw.text((self.move, self.top+8), str('SHUTING DOWN'),  font=self.font2, fill=255)
        self.image_generate()
        self.display()


    def no_data(self):
        self.rectangle()
        self.draw.text((self.move, self.top), datetime.datetime.now().strftime(' %H:%Mh   %d/%m/%Y'),  font=self.font, fill=255)
        self.draw.text((self.move, self.top+7), str('-'*50),  font=self.font, fill=255)
        self.draw.text((self.move, self.top+15), str('      NO DATA'),  font=self.font2, fill=255)
        self.image_generate()
        self.display()