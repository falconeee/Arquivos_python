import time
import RPi.GPIO as GPIO
import signal
from src.controllers import process,fpm_data # Sensor OPC-n3 comunica via SPI
import serial
import Adafruit_MCP3008 # Conversor ADC
from src.sensors import Display, sensor_anemometer, sensor_rainfall, sensor_temperature_relative
from src.controllers import signal_handler,str_results,shutdown_break_energy,select_reboot_shutdown,signal_quality
import csv
from datetime import datetime

# Setting how to call a pin
GPIO.setmode(GPIO.BCM) # BCM = GPIO mapping   /   BOARD = fisical pin mapping

 # MCP3008 - Software SPI configuration:
CLK  = 21
MISO = 19
MOSI = 20
CS   = 16
mcp = Adafruit_MCP3008.MCP3008(clk=CLK, cs=CS, miso=MISO, mosi=MOSI)

# MCP3008 Channel
ADC_CHANNEL_TEMP  = 0
ADC_CHANNEL_HUMI = 1
ADC_CHANNEL_WINDDIR = 2

# Voltage Reference (mV)
V_REF = 5000
V_REF_temp = 1950

rain_bucket = 0.2 # Bucket volume
count_rain = 0 # Bucket tipped count
page = 0 # Page counter
interval = 1 # Setting a interval in seconds
wind_count = 0 # Spin count
dir_offset = 0 # Direction offset from the anemometer
descanso = 0
json_results = {}
pm_data=[]

# Function to set page
def control_page(display,reboot_shutdown_button,click):
    global page
    global json_results
    global descanso

    if json_results:

        if click:
            page = page + 1
            descanso = 0

        if (page == 1):
            display.update_display(True,False,False,False,False,False,reboot_shutdown_button,json_results)

        elif(page == 2):
            display.update_display(False,True,False,False,False,False,reboot_shutdown_button,json_results)

        elif(page == 3):
            display.update_display(False,False,True,False,False,False,reboot_shutdown_button,json_results)

        elif(page == 4):
            display.update_display(False,False,False,True,False,False,reboot_shutdown_button,json_results)
    
        elif(page == 5):
            display.update_display(False,False,False,False,True,False,reboot_shutdown_button,json_results)
        
        elif(page == 6):
            display.update_display(False,False,False,False,False,True,reboot_shutdown_button,json_results)

        if (page >= 6):
            page = 0
    else:
        descanso = 0
        display.no_data()
        time.sleep(1)
        display.page_inicial()

def setup_add(add_button,display:Display,reboot_shutdown_button):
    global page
    global dir_offset
    global rain_bucket
    global json_results

    if (page == 3):
        if (rain_bucket >= 0.5):
            rain_bucket = 0.1
        else:
            rain_bucket = rain_bucket + 0.001

        json_results["Bucket size"] = "{:.3f} mm/s".format(rain_bucket)

        display.update_display(False,False,True,False,False,False,reboot_shutdown_button,json_results)

        time.sleep(0.1)
        cont = 0
        while GPIO.input(add_button) == GPIO.HIGH:
            if (cont == 0):
                time.sleep(1.5)
                cont = 1
            else:
                time.sleep(0.6)
                if GPIO.input(add_button) == GPIO.HIGH:
                    if (rain_bucket >= 0.35):
                        rain_bucket = 0.1
                    else:
                        rain_bucket = rain_bucket + 0.005

                    json_results["Bucket size"] = "{:.3f} mm/s".format(rain_bucket)
                    display.update_display(False,False,True,False,False,False,reboot_shutdown_button,json_results)
                    
    if (page == 4):
        if (dir_offset >= 359):
            dir_offset = dir_offset - 360
        else:
            dir_offset = dir_offset + 1
            
        json_results["Offset angle"]= "{}°".format(dir_offset)

        display.update_display(False,False,False,True,False,False,reboot_shutdown_button,json_results)

        time.sleep(0.1)
        cont = 0
        while GPIO.input(add_button) == GPIO.HIGH:
            if (cont == 0):
                time.sleep(1.5)
                cont = 1
            else:
                time.sleep(0.6)
                if GPIO.input(add_button) == GPIO.HIGH:
                    if (dir_offset >= 360):
                        dir_offset = dir_offset - 360
                    else:
                        dir_offset = dir_offset + 15

                    json_results["Offset angle"]= "{}°".format(dir_offset)
                    display.update_display(False,False,False,True,False,False,reboot_shutdown_button,json_results)
   
def spin(channel):
    global wind_count
    wind_count  = wind_count + 1

def bucket_tipped(channel):
    global count_rain
    count_rain =  count_rain + 1

def sendDataOverSerialPort(data):
    #Set the serial and baud rate
    serData = serial.Serial(port='/dev/ttyUSB5', baudrate=9600)
    
    print('[serialPrinter]: Trying to send data over serial port...')

    if serData.isOpen():
        try:
            serData.flushInput()
            serData.flushOutput()
            serData.write(bytes(data,'iso-8859-1'))
            print('[serialPrinter]: Data sent successfully!')
        except Exception as e1:
            logMsg ='[serialPrinter]: Communication error...:' + str(e1)
            print(logMsg)
     
# Iniciando o Display
display = Display()
display.page_load()
display.page_inicial()

# Defining buttons
# wind_speed_sensor - Setting button - GPIO5
wind_speed_sensor = 5
GPIO.setup(wind_speed_sensor, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# function_count_page - Setting button - GPIO23
function_count_page = 24
GPIO.setup(function_count_page, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

# rain_sensor - Setting button - GPIO6
rain_sensor = 6
GPIO.setup(rain_sensor, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

# add_button - Setting button - GPIO24
add_button = 25
GPIO.setup(add_button, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

# Reboot / Shuttdown - Setting button - GPIO 12
reboot_shutdown_button = 12
GPIO.setup(reboot_shutdown_button, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

# shutdown - Setting button - GPIO 18
shutdown = 26
GPIO.setup(shutdown, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

# Buttons actions
# wind_speed_sensor - spin
GPIO.add_event_detect(wind_speed_sensor, GPIO.RISING,
                    callback = spin)
# function_count_page - page_number
GPIO.add_event_detect(function_count_page, GPIO.RISING,
                    callback = lambda x: control_page(display,reboot_shutdown_button,True), bouncetime = 500)
# rain_sensor - bucket_tipped
GPIO.add_event_detect(rain_sensor, GPIO.FALLING,
                    callback = bucket_tipped, bouncetime = 150)
# add_button - setup_function
GPIO.add_event_detect(add_button, GPIO.RISING,
                    callback = lambda x: setup_add(add_button,display,reboot_shutdown_button), bouncetime = 300)
# wind_speed_sensor - spin
GPIO.add_event_detect(reboot_shutdown_button, GPIO.RISING,
                    callback = lambda x: select_reboot_shutdown(reboot_shutdown_button,display), bouncetime = 1000)
# Shutdown
GPIO.add_event_detect(shutdown, GPIO.RISING,
                    callback = lambda x: shutdown_break_energy(display), bouncetime = 1000)

# Callback for CTRL+C
signal.signal(signal.SIGINT, signal_handler)


while True:
    
    wind_count = 0 #para nao acumular as velocidades medidas

    debug = True # Set True to print the results in the Pythron Idle
    # Getting date and time
    begin = time.time()

    process(debug=debug, config='opc_dust.conf')
    
    pm_data = fpm_data()

    end = time.time()
    delta = float(end - begin)
    
    # Velocidade do vento e direção
    wind_speed_ms,_,wind_angle = sensor_anemometer(mcp,delta,ADC_CHANNEL_WINDDIR,V_REF,wind_count,dir_offset)

    # Volume da chuva
    rain_volume_per_sec = sensor_rainfall(delta,count_rain,rain_bucket)

    # temperatura e humidade
    temp,humi = sensor_temperature_relative(ADC_CHANNEL_TEMP,ADC_CHANNEL_HUMI,V_REF_temp,mcp)

    # Sinal LTE
    _,quality = signal_quality()

    json_results = str_results(temp,humi,wind_speed_ms,wind_angle,rain_bucket,rain_volume_per_sec,dir_offset,pm_data,quality)

    if debug:
        print(json_results)

    #Enviando dados pelo serial
    #data = str(json_results)
    #sendDataOverSerialPort(data+"\n\n")

    #Escreve no .csv
    f = open('data2.csv','a')
    row_csv = datetime.now().strftime(' %H:%Mh   %d/%m/%Y')+";"+str(temp)+";"+str(humi)+";"+ str(wind_speed_ms)+";"+ str(wind_angle)+";"+ str(rain_bucket)+";"+ str(rain_volume_per_sec)+";"+ str(dir_offset)+";"+ str(pm_data)+";"+ str(quality)+";"

    with open("data2.csv",'a') as fd:
        fd.write(row_csv+'\n')
    
    
    # Volta a pagina inicial a cada 3 segundos 
    descanso = descanso+1
    if descanso>2:
        display.page_inicial()
        descanso=0
        page=0
    elif page==0: 
        display.page_inicial()
    else:
        control_page(display,reboot_shutdown_button,False)

    time.sleep(interval)


    
