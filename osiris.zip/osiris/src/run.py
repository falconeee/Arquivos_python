import serial
import time
import os.path
import yaml



"""  ETAPA 1  """

arquivo = "config.yaml"

with open(("/home/pi/osiris/config/"+arquivo), 'r') as config:
  config = yaml.safe_load(config)

from func_aux import cria_comando, comando_F, comando_1_mem, comando_1_leitura, comando_a_units, comando_a_scales, comando_a_offset

#from abre_yaml import config

# setup inicial
modelo = config["modelo"]
serie = config["serie"]
intervalo1 = config["intervalo1"]
intervalo2 = config["intervalo2"]

#Define a conexão serial com o osiris
osiris = serial.Serial(
    port=config["port_serial"],
    baudrate=9600,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    timeout=1
    )

# Abre conexão com o osiris
osiris.isOpen()

# Verifica se existe arquivo csv, senão cria uma
if not os.path.isfile("./data/"+config["nome_arquivo_csv"]):
    cabecalho = ""
    for cols in config["colunas_csv"]:
        cabecalho = cabecalho+cols+";"

    with open("/home/pi/osiris/data/"+config["nome_arquivo_csv"],'a') as fd:
        fd.write(cabecalho+'\n')



"""  ETAPA 2  """

# Verifica quantidade de Samples
code = "F"
com = modelo + serie + code

# Envia o comando para o osiris
osiris.write(cria_comando(com).encode())

# Lê a resposta do osiris
out = ""
out = osiris.read(100).decode()



"""  ETAPA 3  """

#Flag2 para saber se é micro ou miligramas
flag_2 = out[32:34]
flag_2 = bin(int(flag_2, 16))[2:].zfill(8) #garante 8 dígitos
flag_2 = flag_2[:1]

#Descobre units e scales dos valores
code_units_ext = "a" + "0200"

if (flag_2 == 0):
    code_units_int = "a" + "01C0"
    code_scales = "a" + "0440"
else:
    code_units_int = "a" + "0240"
    code_scales = "a" + "0480"

    
com_units_int = modelo + serie + code_units_int
com_units_ext = modelo + serie + code_units_ext
com_scales = modelo + serie + code_scales
            
#Envia o comando para o osiris
osiris.write(cria_comando(com_units_int).encode())
#Lê a resposta do osiris
out_units = ""
out_units_int = osiris.read(100).decode()

#Envia o comando para o osiris
osiris.write(cria_comando(com_units_ext).encode())
#Lê a resposta do osiris
out_units = ""
out_units_ext = osiris.read(100).decode()

#Envia o comando para o osiris
osiris.write(cria_comando(com_scales).encode())
#Lê a resposta do osiris
out_scales = ""
out_scales = osiris.read(100).decode()


#Descbore offsets dos valores
code_offset = "a" + "04C0"
com_offset = modelo + serie + code_offset
#Envia o comando para o osiris
osiris.write(cria_comando(com_offset).encode())
#Lê a resposta do osiris
out_offset = ""
out_offset = osiris.read(100).decode()

#Chama funções
unit_tsp, unit_pm10, unit_pm25, unit_pm1, unit_ext1, unit_ext2, unit_wspd, unit_wdir = comando_a_units(com_units_int, out_units_int, com_units_ext, out_units_ext)
sc_tsp, sc_pm10, sc_pm25, sc_pm1, sc_ext1, sc_ext2, sc_wspd, sc_wdir = comando_a_scales(com_scales, out_scales)
off_tsp, off_pm10, off_pm25, off_pm1, off_ext1, off_ext2, off_wspd, off_wdir = comando_a_offset(com_offset, out_offset)

print("\n")



"""  ETAPA 4  """

while True:
    
    #Limpa memória
    print("Limpando a memória... \n")
    
    code = "5"
    com = modelo + serie + code
    #Envia o comando para o osiris
    osiris.write(cria_comando(com).encode())
    #Pausa pelo tempo do intervalo2
    time.sleep(intervalo2)

    #Lê a resposta do osiris
    out = ""
    out = osiris.read(100).decode()
    #Imprime a resposta
    #print(out + "\n\n")


    #Inicia uma nova Sample
    code = "4"
    com = modelo + serie + code
    #Envia o comando para o osiris
    osiris.write(cria_comando(com).encode())
    
    #Lê a resposta do osiris
    out = ""
    out = osiris.read(100).decode()
    #Imprime a resposta
    print("Iniciando nova amostra" + "\r")
    print(time.ctime())
    #print("\n")
    
    #Pausa pelo tempo do Intervalo
    time.sleep(intervalo1)

    #Encerra a Sample
    code = "6"
    com = modelo + serie + code
    #Envia o comando para o osiris
    osiris.write(cria_comando(com).encode())
    
    #Lê a resposta do osiris
    out = ""
    out = osiris.read(100).decode()
    #Imprime a resposta
    print("Fim da amostra." + "\r")
    print(time.ctime())
    #print("\n")

    #Pausa pelo tempo do Intervalo
    time.sleep(intervalo2)



    """  ETAPA 5  """
    
    #Le último espaço de memória
    code = "F"
    com = modelo + serie + code
    #Envia o comando para o osiris
    osiris.write(cria_comando(com).encode())
    
    #Lê a resposta do osiris
    out = ""
    out = osiris.read(100).decode()
    mem = out[7:9]
    #Imprime a resposta
    #print(mem + "\r")

    #Contador para o local das memórias
    mem = "{0:x}".format(int(mem, 16) + 262)

    #Descobre local da última Sample
    code = "10" + mem
    com = modelo + serie + code
    #Envia o comando para o osiris
    osiris.write(cria_comando(com).encode())
    #Lê a resposta do osiris
    out = ""
    out = osiris.read(100).decode()

    #Faz leitura do cabeçalho
    leitura = out[11:15]
    cabecalho = ""
    
    for cab in range(3):
        #print("Cabeçalho:", leitura, "linha:", cab)
        code = "1" + leitura
        com = modelo + serie + code
        #Envia o comando para o osiris
        osiris.write(cria_comando(com).encode())
        #Lê a resposta do osiris
        out = ""
        out = osiris.read(100).decode()
    
        #Adiciona local  das memorias
        cabecalho = cabecalho + comando_1_leitura(com, out, leitura)
        
        #Vai para a próxima leitura de cabeçalho
        leitura = hex(int(leitura, 16) + 16)
        leitura = "00" + leitura
        leitura = leitura.replace("x", "")
        leitura = leitura[-4:]

    #print(cabecalho)
    
    
    
    """  ETAPA 6  """
    
    #Preenche o arquivo .CSV
    #Hora inicial e final da amostra
    timestamp_ini = cabecalho[12:14] + "/" + cabecalho[18:20] + "/" + cabecalho[16:18] + " " + \
                cabecalho[8:10] + ":" + cabecalho[10:12] + ":" + cabecalho[14:16]
    
    timestamp_fim = cabecalho[116:118] + "/" + cabecalho[122:124] + "/" + cabecalho[120:122] + " " + \
                cabecalho[112:114] + ":" + cabecalho[114:116]
    

    #converte valores das amostras
    tsp = "{:.2f}".format((int(cabecalho[64:68], 16) - off_tsp) * sc_tsp)
    pm10 = "{:.1f}".format((int(cabecalho[68:72], 16) - off_pm10) * sc_pm10)
    pm25 = "{:.2f}".format((int(cabecalho[72:76], 16) - off_pm25) * sc_pm25)
    pm1 = "{:.2f}".format((int(cabecalho[76:80], 16) - off_pm1) * sc_pm1)
    ext1 = "{:.1f}".format((int(cabecalho[80:84], 16) - off_ext1) * sc_ext1)
    ext2 = "{:.1f}".format((int(cabecalho[84:88], 16) - off_ext2) * sc_ext2)
    wspd = "{:.1f}".format((int(cabecalho[88:92], 16) - off_wspd) * sc_wspd)
    wdir = "{:.1f}".format((int(cabecalho[92:96], 16) - off_wdir) * sc_wdir)

    row_csv = timestamp_ini+";"+timestamp_fim+";"+ tsp+";"+ unit_tsp+";"+ pm10+";"+ unit_pm10+";"+ pm25+";"+ unit_pm25+";"+ pm1+";"+  \
                         unit_pm1+";"+ ext1+";"+ unit_ext1+";"+ ext2+";"+ unit_ext2+";"+ wspd+";"+ unit_wspd+";"+ wdir+";"+ unit_wdir+";"


    with open("/home/pi/osiris/data/"+config["nome_arquivo_csv"],'a') as fd:
        fd.write(row_csv+'\n')

    print("Registro feito no arquivo .csv" + "\r\r\n")
